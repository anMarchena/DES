**EX_04**

Este código en PHP crea un formulario que permite ingresar información personal, como nombre, apellidos, contraseña, tipo (Alumno o Profesor), una foto, edad, comentarios y un campo oculto llamado "test". 
Cuando el usuario envía el formulario, el código verifica los valores ingresados y muestra los datos por pantalla. 
También muestra el valor del campo oculto "test".