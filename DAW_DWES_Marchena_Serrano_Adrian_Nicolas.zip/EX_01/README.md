**EX_01**

Primero he creado un formulario HTML con un campo de entrada de texto y un botón de envío.
Cuando el formulario se envía, el código recoge lo enviado desde el formulario.
Luego, calcula la longitud de la palabra utilizando la función strlen.
Finalmente, muestra la longitud de la palabra junto con la palabra ingresada en la página web.