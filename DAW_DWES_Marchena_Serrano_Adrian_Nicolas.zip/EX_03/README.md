**EX_03**

Primero he creado un formulario HTML con un campo de entrada numerica y un botón de envío.
Cuando el formulario se envía, el código recoge lo enviado desde el formulario.
Luego, con un for, imprime el numero de lineas puestas en el formulario.
Por ultimo, muestra el resultado de la operacion con un echo.
Tambien te he puesto un pequeño easter egg.