**EX_02**

Primero he creado un formulario HTML con un campo de entrada numerica, seguido por un desplegable para seleccionar la operacion matematica, seguido por otro campo de entrada numerica y un botón de envío.
Cuando el formulario se envía, el código recoge lo enviado desde el formulario.
Luego, calcula el resultado de la oeracion con un switch donde se contemplan las 4 operaciones matematicas.
Por ultimo, muestra el resultado de la operacion con un echo.